<?php

class M_database extends CI_Model {

	public function select($sql)
	{
		$query = $this->db->query($sql);
		return $query->result();
	}

	public function insert($table, $data)
	{
		$this->db->insert($table, $data);
	}

	public function update($table, $data, $where)
	{
		$this->db->where($where);
		$this->db->update($table, $data);
	}

	public function delete($table, $where)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}

}