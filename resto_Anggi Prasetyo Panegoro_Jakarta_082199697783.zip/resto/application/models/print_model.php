	<?php
	class print_model extends CI_model{

	public function show_pesanan_byid($data)
	{
		$this->db->select('*');
		$this->db->from('pesanan');
		$this->db->where('id',$data);
		$this->db->order_by('nama_makanan', "desc");
		$query= $this->db->get();
		return $query;
	}
}