<?php 

class resto_model extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function get_all_user() {
		$data = $this->db->get('restoran');
		return $data;
	}

	public function get_user_by_id($id) {
		$this->db->where('nip', $id);
		$data = $this->db->get('user');

		if($data->num_rows() > 0){
			return $data->row();
		}

		return NULL;
	}

}