<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pelayan extends CI_Controller {
public function __construct()
	{
		parent::__construct();

		$this->load->model('m_database');
		if($this->session->userdata('login') != 'aktif')
		{
			$this->session->set_flashdata('notif', '<div class="alert alert-success">Anda harus login dulu</div>');
			redirect('Login/index');
		}
	}
	public function index()
	{
		$query = "select * from makanan";
		$this->load->model('m_database');
		$data['daftar_makanan'] = $this->m_database->select($query);
		$this->load->view('resto/V_pelayan', $data);
	}

	public function pesan()
	{
		if($this->input->post('submit'))
		{
			$id = $this->input->post('id');

			$query = "select * from pesanan where id = '$id'";
			$result = $this->m_database->select($query);
			if($result)
			{
				$this->session->set_flashdata('notif', '<div class="alert alert-warning">ID pendeta sudah ada</div>');
				redirect('pelayan/pesan');
			}
			else
			{
				$data_pesan = array(
					'id' => $this->input->post('id'),
					'nama_makanan' => $this->input->post('nama_makanan'),
					'banyak' => $this->input->post('banyak'),
					'no_meja' => $this->input->post('no_meja'),
				);

				$this->load->model('m_database');
				$this->m_database->insert('pesanan', $data_pesan);
				$this->session->set_flashdata('notif', '<div class="alert alert-success">Pesanan telah disimpan</div>');
				redirect('pelayan/index');
			}
		}
		else
		{
			$this->load->view('resto/V_pesan');
		}

	}

	public function pesanan()
	{
		$query = "select * from pesanan";
		$this->load->model('m_database');
		$data['daftar_pesanan'] = $this->m_database->select($query);
		$this->load->view('resto/V_pesanan', $data);
	}

	public function update($idd)
	{
		$sql= "SELECT * FROM pesanan WHERE id ='$idd'";
		$query['data'] = $this->m_database->select($sql);

		$this->load->view('resto/V_update', $query);
		
	}
	public function Update2()
	{
		if($this->input->post('submit'))
		{
			$idd = $this->input->post('id');
			$data = array(

				'nama_makanan' => $this->input->post('nama_makanan'),
				'banyak' => $this->input->post('banyak'),
				'no_meja' => $this->input->post('no_meja')
			);
			
			$where = array('id' => $idd);
			$this->m_database->update('pesanan', $data, $where);
			$this->session->set_flashdata('notif', '<div class="alert alert-success">Data pesanan berhasil diupdate</div>');
			redirect('pelayan/pesanan');
		}
		else
		{
    	   $this->load->view ('resto/V_update');
        }	
	}
	public function delete2($id)
	{
		$where = array('id' => $id);
		$this->load->model('m_database');
		$this->m_database->delete('pesanan', $where);
		$this->session->set_flashdata('notif', '<div class="alert alert-success">Data jemaat telah dihapus</div>');
		redirect('pelayan/pesanan');
	}

	/*public function print($id){
    	$sql="SELECT * FROM pesanan WHERE id='$id' ORDER BY nama_makanan DESC";
    	$query['data']=$this->print_model->select($sql);
    	$this->load->view('resto/V_print',$query);
*/
}
