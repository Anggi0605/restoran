<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kasir extends CI_Controller {
public function __construct()
	{
		parent::__construct();

		$this->load->model('m_database');
		if($this->session->userdata('login') != 'aktif')
		{
			$this->session->set_flashdata('notif', '<div class="alert alert-success">Anda harus login dulu</div>');
			redirect('Login/index');
		}
	}
	public function index()
	{
		$query = "select * from pesanan";
		$this->load->model('m_database');
		$data['daftar_pesanan'] = $this->m_database->select($query);
		$this->load->view('resto/V_updatekasir', $data);
	}

	public function update($idd)
	{
		$sql= "SELECT * FROM pesanan WHERE id ='$idd'";
		$query['data'] = $this->m_database->select($sql);

		$this->load->view('resto/V_updatekas', $query);
		
	}

	public function Update2()
	{
		if($this->input->post('submit'))
		{
			$idd = $this->input->post('id');
			$data = array(

				'nama_makanan' => $this->input->post('nama_makanan'),
				'banyak' => $this->input->post('banyak'),
				'no_meja' => $this->input->post('no_meja')
			);
			
			$where = array('id' => $idd);
			$this->m_database->update('pesanan', $data, $where);
			$this->session->set_flashdata('notif', '<div class="alert alert-success">Data pesanan berhasil diupdate</div>');
			redirect('kasir/index');
		}
		else
		{
    	   $this->load->view ('resto/V_updatek');
        }	
	}

	public function delete2($id)
	{
		$where = array('id' => $id);
		$this->load->model('m_database');
		$this->m_database->delete('pesanan', $where);
		$this->session->set_flashdata('notif', '<div class="alert alert-success">Data jemaat telah dihapus</div>');
		redirect('kasir/index');
	}
}