<?php

class Login extends CI_Controller {
public function index()
	{
		if($this->input->post('submit'))
		{
			$userid = $this->input->post('userid');
			$password = $this->input->post('password');

			$query = "select * from user where nip = '$userid' and password = md5('$password')";
			$this->load->model('m_database');
			$result = $this->m_database->select($query);

			if($result)
			{
				foreach ($result as $row) 
				{
					$level = $row->level;
				}

				$session_data = array(
					'login' => 'aktif',
					'NIP' => $row->nip
				);
				$this->session->set_userdata($session_data);

				if($row->level == 'pelayan')
				{
					redirect('pelayan/index');
				}
				else if($row->level == 'kasir')
				{
					redirect('kasir/index');
				}
				
			}
			else
			{
				$this->session->set_flashdata('notif', '<div class="alert alert-warning">User ID atau password salah</div>');
				redirect('login/index');
			}
		}
		else
		{
			$this->load->view ('resto/V_login');
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('Login/index');
	}
}
