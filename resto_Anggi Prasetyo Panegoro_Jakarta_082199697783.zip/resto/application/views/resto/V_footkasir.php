<section>
		<div class="fixed-action-btn vertical">
			<a class="btn-floating btn-large red pulse"> <i class="large material-icons">mode_edit</i> </a>
			<ul>
				<li><a class="btn-floating yellow darken-1" href="<?php echo base_url(); ?>index.php/pelayan/pesan"><i class="material-icons">format_quote</i></a> </li>
				</ul>
		</div>
	</section>
	<!--SCRIPT FILES-->
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/materialize.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
</body>