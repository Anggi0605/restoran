<!DOCTYPE html>
<html lang="en">

<head>
	<title>World Best Local Directory Website template</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- ALL CSS FILES -->
	<link href="<?php echo base_url(); ?>assets/css/materialize.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link href="<?php echo base_url(); ?>assets/css/responsive.css" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
	<div id="preloader">
		<div id="status">&nbsp;</div>
	</div>
	<section class="tz-login">
		<div class="tz-regi-form">
			<h4>Sign In</h4>
			<p>It's free and always will be.</p>
			<form class="col s12" method="post" action="<?php echo base_url(); ?>index.php/login/index">
				<div class="row">
					<div class="input-field col s12">
						<input type="text" name="userid" placeholder="User ID" class="Validate">
						<label>User Name</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<input type="password" name="password" placeholder="Password" class="Validate">
						<label>Password</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12"> <i class="waves-effect waves-light btn-large full-btn waves-input-wrapper" style=""><input type="submit" name="submit" value="SUBMIT" class="waves-button-input"></i> </div>
				</div>
				<div class="text-center"><?php echo $this->session->flashdata('notif'); ?></div>
			</form>
			<p><a href="admin-pass.html">forgot password</a> | Are you a new user ? <a href="admin-register.html">Register</a> </p>
		</div>
	</section>
	<!--SCRIPT FILES-->
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/materialize.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
</body>

</html>