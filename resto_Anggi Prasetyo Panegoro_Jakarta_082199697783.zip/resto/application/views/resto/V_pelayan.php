<?php $this->load->view('resto/v_headpelayan');?>

						
			<div class="sb2-2">
				<!--== breadcrumbs ==-->
				<div class="sb2-2-2">
					<ul>
						<li><a href="index.html"><i class="fa fa-home" aria-hidden="true"></i> Home</a> </li>
						<li class="active-bre"><a href="#"> Menu</a> </li>
						<li class="page-back"><a href="#"><i class="fa fa-backward" aria-hidden="true"></i> Back</a> </li>
					</ul>
				</div>
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp">
									<div class="inn-title">
										<h4>MAKANAN</h4>
										<!-- Dropdown Structure -->
									</div>
									<div class="tab-inn">
										<div class="table-responsive table-desi">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>Pic</th>
														<th>Name</th>
														<th>Category</th>
														<th>Status</th>
														<th>View</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach ($daftar_makanan as $row): ?>
													<tr>
														<td><span class="list-img"><img src="<?php echo base_url(); ?>assets/images/users/1.png" alt=""></span> </td>
														<td><a href="#"><span class="list-enq-name"><?php echo $row->nama_makanan; ?></span></a> </td>
														<td><?php echo $row->jenis_makanan; ?></td>
														<td> <span class="label label-primary">Un Read</span> </td>
														<td> <span class="label label-primary">View</span> </td>
													</tr>
													<?php endforeach; ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>

<?php $this->load->view('resto/v_footpelayan');?>	

