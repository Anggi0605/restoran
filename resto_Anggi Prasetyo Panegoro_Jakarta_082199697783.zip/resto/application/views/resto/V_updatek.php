<?php $this->load->view('resto/v_headkasir');?>

	<div class="sb2-2">
				<!--== breadcrumbs ==-->
				<div class="sb2-2-2">
					<ul>
						<li><a href="index.html"><i class="fa fa-home" aria-hidden="true"></i> Home</a> </li>
						<li class="active-bre"><a href="#"> Order</a> </li>
						<li class="page-back"><a href="#"><i class="fa fa-backward" aria-hidden="true"></i> Back</a> </li>
					</ul>
				</div>
				<div class="tz-2 tz-2-admin">
					<div class="tz-2-com tz-2-main">
						<h4>Pesan</h4>
						<!-- Dropdown Structure -->
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp ad-mar-to-min">
									<div class="tab-inn ad-tab-inn">
										<div class="tz2-form-pay tz2-form-com">
											<div class="tz2-form-pay tz2-form-com">
												<form method="post" action="<?php echo base_url(); ?>index.php/kasir/Update2">
													<?php
                            						foreach($data as $row){
                            
                           							 ?>
                           							 <input type="hidden" id="hide" name="id" value="<?php echo $row->id; ?>">
													<div class="row">
														<div class="input-field col s12 m6">
															<input type="text"  name="nama_makanan" value="<?php echo $row->nama_makanan; ?>">
															<label>Nama Makanan/Minuman</label>
														</div>
														<div class="input-field col s12 m6">
															<input type="text"  name="banyak" value="<?php echo $row->banyak; ?>">
															<label>Banyak pesanan</label>
														</div>
														<div class="row">
														<div class="input-field col s12 m6">
															<input type="number"  name="no meja" value="<?php echo $row->no_meja; ?>">
															<label>Nomor Meja</label>
														</div>
														</div>
													</div>
											<div class="row">
												<div class="input-field col s12"> <i class="waves-effect waves-light btn-large full-btn waves-input-wrapper" style=""><input type="submit" name="submit" value="Submit" class="waves-button-input"></i> </div>
											</div>
											<?php echo form_close(); } ?>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $this->load->view('resto/v_footkasir');?>	

