<?php ?>
<html>
<head>
	<title></title>
</head>
<body>

<?php echo $tanggal = date("l,d-m-y"); print "<center><h3>Pesanan <br> Tanggal: $tanggal</h3></center>";?>
<center><table border="1px">
<?php
foreach ($data as $row){
?>
<td><?php echo $row->Tahun; ?></td>
<tr>
	<th>&nbsp;nama_makanan&nbsp;</th>
	<th>&nbsp;banyak&nbsp;</th>
	<th>&nbsp;no_meja&nbsp;</th>
</tr>


<tr>
	                               
                                  <tr>
                                  <td>Pesanan</td>
                                  <td><?php echo $row->id; ?></td>
                                  <td>Ibadah Keluarga</td>
                                  <td><?php echo $row->nama_makanan; ?></td>
                                  <td><?php echo $row->banyak; ?></td>
                                  <td><?php echo $row->no_meja; ?></td>
                                </tr>
                                
</tr>
<?php
} ?>
</table></center>
</body>
</html>