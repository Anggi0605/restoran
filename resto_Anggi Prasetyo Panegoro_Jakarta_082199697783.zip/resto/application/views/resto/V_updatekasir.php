<?php $this->load->view('resto/v_headkasir');?>

<div class="sb2-2">
				<div class="tz-2 tz-2-admin">
					<div class="tz-2-com tz-2-main">
						<h4>All Listing</h4> 
						<!-- Dropdown Structure -->
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp ad-inn-page">
									<div class="tab-inn ad-tab-inn">
										<div class="table-responsive">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>Listing</th>
														<th>Name</th>
														<th>Jumlah</th>
														<th>No Meja</th>
														<th>Delete</th>
														<th>Edit</th>
													</tr>
												</thead>
												<tbody>
														<?php foreach ($daftar_pesanan as $row): ?>
                              							<tr>
														<td><span class="list-img"><img src="<?php echo base_url(); ?>assets/images/icon/dbr1.jpg" alt=""></span> </td>
														
                                 						
                                  						<td><?php echo $row->nama_makanan; ?></td>
                                  						<td><?php echo $row->banyak; ?></td>
                                  						<td><?php echo $row->no_meja; ?></td>
                                  
														<td> <a href="<?php echo base_url(); ?>index.php/kasir/delete2/<?php echo $row->id; ?>"><i class="fa fa-eye"></i></a> </td>
														<td> <a href="<?php echo base_url(); ?>index.php/kasir/update/<?php echo $row->id; ?>"><i class="fa fa-edit"></i></a> </td>
													</tr>
													
													<?php endforeach; ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>

<?php $this->load->view('resto/v_footkasir');?>	

